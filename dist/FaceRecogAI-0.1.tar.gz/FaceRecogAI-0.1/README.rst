A brief into to this package. This was made to practice CV2 image
processing, as well as simplify the process of including facial
recognition and blurring in my further projects which will feature them
commonly. There are 3 functions in the package right now, with more to
be added, with different principles, including deep learning and others,
such as video camera systems as well. 1. detect_face(img_file): It
contains a simple Haar cascade recognition system utilized by OpenCV.
Creates a rectangle around the face 2. block_face(img_file): It contains
a simple Haar cascade recognition system utilized by OpenCV. Creates a
rectangle around the face filled in, as to block the face with a white
screen. 3. blur_face(img_file): It contains a simple Haar cascade
recognition system utilized by OpenCV. Creates a rectangle-shaped blur
around the face using Gaussian blur.
